
#!/bin/bash

echo "================================"
echo " KL OS Automatic Build Script (FIXED)"
echo "================================"

# Создаём ISO структуру
mkdir -p iso/boot/grub
mkdir -p iso/live

# Копируем kernel
cp rootfs/boot/vmlinuz iso/live/vmlinuz

# Создаём squashfs с корневой файловой системой
sudo mksquashfs rootfs iso/live/filesystem.squashfs -e boot

# Создаём GRUB конфиг
cat <<EOF > iso/boot/grub/grub.cfg
set timeout=5
set default=0

menuentry "KL OS Live" {
    linux /live/vmlinuz boot=live
}
EOF

# Собираем ISO с правильным загрузчиком GRUB
echo "Создаём bootable ISO через grub-mkrescue..."
grub-mkrescue -o KL_OS.iso iso

echo ""
echo "================================"
echo "KL OS ISO CREATED"
echo "Файл: KL_OS.iso"
echo "================================"
