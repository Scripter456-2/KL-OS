# KL OS

Experimental Linux OS concept.

Built using:
- Linux From Scratch (LFS)
- Ubuntu build environment
- QEMU for testing

Features:
- Lightweight desktop
- XP-style layout
- Simple core apps
