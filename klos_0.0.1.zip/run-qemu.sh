#!/bin/bash
qemu-system-x86_64 -m 2048 -drive file=klos.img,format=raw -kernel rootfs/boot/vmlinuz -append "root=/dev/sda rw init=/sbin/init"
