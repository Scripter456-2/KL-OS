#!/bin/bash
echo "Building KL OS disk..."
qemu-img create klos.img 10G
mkdir -p mnt
sudo mount -o loop klos.img mnt
sudo cp -r rootfs/* mnt/
sudo umount mnt
echo "KL OS image created: klos.img"
