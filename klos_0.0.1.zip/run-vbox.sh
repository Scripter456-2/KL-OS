
#!/bin/bash
echo "Запуск KL OS в VirtualBox (предварительно создайте VM 'KL_OS' с CD-ROM)..."
VBoxManage startvm "KL_OS" --type gui
