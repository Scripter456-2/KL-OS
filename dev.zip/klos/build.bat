@echo off

echo ==========================
echo KL OS Builder
echo ==========================

echo Starting Linux build script...

wsl bash build.sh

echo.
echo Build finished.
pause